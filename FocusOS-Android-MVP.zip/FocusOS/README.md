# FocusOS Android MVP

A native Kotlin Android Studio project for a personal-device study focus app.

## What works in this MVP
- Enter a study topic and duration (1–600 minutes).
- Choose installed launchable apps to allow during a session.
- Start a timed focus session.
- Accessibility service detects foreground app/window changes and brings up a blocking screen for apps outside the allowlist.
- Emergency exit ends the session after confirmation.
- Session totals and count are stored locally in SharedPreferences.

## Important Android limitations
This is an interruption-based blocker, not a secure kiosk. Android may briefly show the blocked app before FocusOS returns to its block screen. The launcher, Android Settings, System UI, permission controller and keyboard/input method are exempted so the phone remains usable and recoverable. Some OEM battery-management settings may stop background accessibility services.

For stronger enforcement on a personally owned device, a later version can use Android Lock Task / device-owner provisioning. That requires provisioning the device as a device owner and is not something a normal APK can silently enable.

## Build and install
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this `FocusOS` folder in Android Studio.
3. Allow Gradle sync; use JDK 17.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated `app-debug.apk` on your Android phone.
6. Open FocusOS > **ENABLE APP-BLOCKING ACCESS** > enable FocusOS.
7. Return to FocusOS, tick the apps you want to use for studying, and tap **SAVE ALLOWLIST**.
8. Enter a topic and duration, then tap **START FOCUS SESSION**.

## Notes
- `QUERY_ALL_PACKAGES` is used to populate the local installed-app picker. This is appropriate for a personal sideloaded build; Play Store distribution has additional policy restrictions.
- All session data stays on-device.
- Package name: `com.focusos.app`
