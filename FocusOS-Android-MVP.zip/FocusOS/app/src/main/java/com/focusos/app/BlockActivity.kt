package com.focusos.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        render()
    }

    private fun render() {
        val bg = Color.rgb(9, 11, 18)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 32, 36, 32)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "Stay in your focus zone"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "This app isn't on your study allowlist.\n\nTopic: ${FocusPrefs.topic(this@BlockActivity)}"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 28)
        }
        val back = Button(this).apply {
            text = "RETURN TO STUDY"
            setOnClickListener { openHome() }
        }
        val exit = Button(this).apply {
            text = "Emergency exit · end session"
            setOnClickListener {
                android.app.AlertDialog.Builder(this@BlockActivity)
                    .setTitle("End focus session?")
                    .setMessage("Your study session will stop and all apps will be available.")
                    .setNegativeButton("Keep studying", null)
                    .setPositiveButton("End session") { _, _ ->
                        FocusPrefs.finish(this@BlockActivity)
                        openHome()
                    }.show()
            }
        }
        panel.addView(title)
        panel.addView(sub)
        panel.addView(back)
        panel.addView(exit)
        setContentView(panel)
    }

    private fun openHome() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(i)
        finish()
    }
}
