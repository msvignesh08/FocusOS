package com.focusos.app

import android.content.Context

object FocusPrefs {
    private const val PREFS = "focusos_prefs"
    private const val KEY_ALLOWED = "allowed_packages"
    private const val KEY_END = "session_end"
    private const val KEY_TOPIC = "topic"
    private const val KEY_MINUTES = "minutes"
    private const val KEY_TOTAL = "total_minutes"
    private const val KEY_SESSIONS = "sessions"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun allowed(c: Context): Set<String> = p(c).getStringSet(KEY_ALLOWED, emptySet())?.toSet() ?: emptySet()
    fun setAllowed(c: Context, set: Set<String>) { p(c).edit().putStringSet(KEY_ALLOWED, set.toSet()).apply() }
    fun end(c: Context): Long = p(c).getLong(KEY_END, 0L)
    fun active(c: Context): Boolean = end(c) > System.currentTimeMillis()
    fun start(c: Context, topic: String, minutes: Int) {
        p(c).edit().putString(KEY_TOPIC, topic).putInt(KEY_MINUTES, minutes)
            .putLong(KEY_END, System.currentTimeMillis() + minutes * 60_000L).apply()
    }
    fun finish(c: Context) {
        val pref = p(c)
        val end = pref.getLong(KEY_END, 0L)
        val mins = pref.getInt(KEY_MINUTES, 0)
        if (end > 0L) {
            val elapsed = (((System.currentTimeMillis() - (end - mins * 60_000L)) / 60_000L).toInt()).coerceIn(0, mins)
            pref.edit().putInt(KEY_TOTAL, pref.getInt(KEY_TOTAL, 0) + elapsed)
                .putInt(KEY_SESSIONS, pref.getInt(KEY_SESSIONS, 0) + 1).putLong(KEY_END, 0L).apply()
        }
    }
    fun topic(c: Context) = p(c).getString(KEY_TOPIC, "") ?: ""
    fun total(c: Context) = p(c).getInt(KEY_TOTAL, 0)
    fun sessions(c: Context) = p(c).getInt(KEY_SESSIONS, 0)
}
