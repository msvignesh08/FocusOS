package com.focusos.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class FocusAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !FocusPrefs.active(this)) return
        if (FocusPrefs.end(this) <= System.currentTimeMillis()) {
            FocusPrefs.finish(this)
            return
        }
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || isAlwaysAllowed(pkg)) return
        if (pkg !in FocusPrefs.allowed(this)) {
            val i = Intent(this, BlockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("blocked_package", pkg)
            }
            try { startActivity(i) } catch (_: Exception) { }
        }
    }

    private fun isAlwaysAllowed(pkg: String): Boolean {
        // Keep essential Android surfaces available so the phone remains recoverable.
        val safe = listOf("com.android.systemui", "com.android.permissioncontroller",
            "com.google.android.permissioncontroller", "com.android.settings",
            "com.android.launcher", "com.google.android.inputmethod")
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val homePackage = packageManager.resolveActivity(homeIntent, 0)?.activityInfo?.packageName
        return pkg == homePackage || safe.any { pkg == it || pkg.startsWith(it) } ||
            pkg.contains("launcher", ignoreCase = true) ||
            pkg.contains("inputmethod", ignoreCase = true) ||
            pkg.contains("keyboard", ignoreCase = true)
    }

    override fun onInterrupt() {}
}
