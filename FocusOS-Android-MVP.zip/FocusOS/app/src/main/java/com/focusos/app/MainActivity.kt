package com.focusos.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*
import android.content.pm.PackageManager

data class AppChoice(val label: String, val pkg: String, val icon: android.graphics.drawable.Drawable?)

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 18)
    private val card = Color.rgb(20, 24, 37)
    private val accent = Color.rgb(167, 139, 250)
    private lateinit var topic: EditText
    private lateinit var duration: EditText
    private lateinit var status: TextView
    private lateinit var allowList: LinearLayout
    private val checks = mutableMapOf<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 32)
        }
        scroll.addView(root)

        root.addView(label("FOCUSOS", 13f, accent, true))
        root.addView(label("Own your attention.", 29f, Color.WHITE, true))
        root.addView(label("A quieter phone. A better study session.", 14f, Color.LTGRAY))
        root.addView(space(22))

        val statusCard = panel()
        status = label("", 15f, Color.WHITE, true)
        statusCard.addView(status)
        statusCard.addView(label("Study time: ${FocusPrefs.total(this)} min  ·  Sessions: ${FocusPrefs.sessions(this)}", 13f, Color.LTGRAY))
        root.addView(statusCard)

        root.addView(space(18))
        root.addView(label("NEW STUDY SESSION", 12f, accent, true))
        topic = EditText(this).apply {
            hint = "What are you studying? e.g. Linear Algebra"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize = 16f
            setSingleLine(true); setPadding(16, 14, 16, 14); setBackgroundColor(card)
        }
        root.addView(topic, matchWrap())
        duration = EditText(this).apply {
            hint = "Duration in minutes (e.g. 50)"
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize = 16f
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true); setPadding(16, 14, 16, 14); setBackgroundColor(card)
        }
        val dp = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 }
        root.addView(duration, dp)

        val start = Button(this).apply {
            text = "START FOCUS SESSION"
            setOnClickListener { startSession() }
        }
        root.addView(start, dp)

        val accessibility = Button(this).apply {
            text = "ENABLE APP-BLOCKING ACCESS"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accessibility, dp)

        root.addView(space(22))
        root.addView(label("STUDY APPS ALLOWLIST", 12f, accent, true))
        root.addView(label("Only checked apps are allowed during a session. Android system surfaces and your launcher remain available for safety.", 13f, Color.LTGRAY))
        allowList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(allowList)
        root.addView(Button(this).apply {
            text = "SAVE ALLOWLIST"
            setOnClickListener {
                FocusPrefs.setAllowed(this@MainActivity, checks.filterValues { it.isChecked }.keys)
                Toast.makeText(this@MainActivity, "Study apps saved", Toast.LENGTH_SHORT).show()
            }
        }, matchWrap())
        setContentView(scroll)
        loadApps()
        refreshStatus()
    }

    private fun loadApps() {
        allowList.removeAllViews()
        checks.clear()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull {
                val pkg = it.activityInfo.packageName
                if (pkg == packageName) null else AppChoice(
                    it.loadLabel(pm).toString(), pkg, try { it.loadIcon(pm) } catch (_: Exception) { null })
            }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }

        val saved = FocusPrefs.allowed(this)
        apps.forEach { app ->
            val cb = CheckBox(this).apply {
                text = app.label
                tag = app.pkg
                isChecked = app.pkg in saved
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                setPadding(8, 8, 8, 8)
            }
            checks[app.pkg] = cb
            allowList.addView(cb)
        }
    }

    private fun startSession() {
        val topicText = topic.text.toString().trim()
        val mins = duration.text.toString().toIntOrNull() ?: 0
        if (topicText.isEmpty() || mins !in 1..600) {
            Toast.makeText(this, "Enter a topic and a duration from 1 to 600 minutes.", Toast.LENGTH_LONG).show()
            return
        }
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Enable FocusOS in Accessibility settings first.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        FocusPrefs.setAllowed(this, checks.filterValues { it.isChecked }.keys)
        FocusPrefs.start(this, topicText, mins)
        Toast.makeText(this, "Focus session started", Toast.LENGTH_SHORT).show()
        refreshStatus()
    }

    private fun refreshStatus() {
        val end = FocusPrefs.end(this)
        status.text = if (end > System.currentTimeMillis()) {
            val remaining = ((end - System.currentTimeMillis()) / 60_000L).toInt()
            "●  FOCUS ACTIVE  ·  ${FocusPrefs.topic(this)}  ·  about $remaining min left"
        } else {
            if (end > 0L) FocusPrefs.finish(this)
            "○  READY TO FOCUS"
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == FocusAccessibilityService::class.java.name }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 4, 0, 8)
        }

    private fun panel() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(18, 16, 18, 16)
        setBackgroundColor(card)
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
